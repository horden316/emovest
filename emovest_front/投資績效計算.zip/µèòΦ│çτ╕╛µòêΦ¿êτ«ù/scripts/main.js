$(document).ready(function(){
    $(".navlink").mouseenter(function(){
        $(this).addClass("white")
    })
    $(".navlink").mouseleave(function(){
        $(this).removeClass("white")
    })
    $(".btn").mouseenter(function(){
        $(this).addClass("white")
    })
    $(".btn").mouseleave(function(){
        $(this).removeClass("white")
    })
    $(".content h4").mouseenter(function(){
        $(this).addClass("white")
    })
    $(".content h4").mouseleave(function(){
        $(this).removeClass("white")
    })
    $("#tab h3").mouseenter(function(){
        $(this).addClass("orange")
    })
    $("#tab h3").mouseleave(function(){
        $(this).removeClass("orange")
    })
})

// Any of the following formats may be used
constctx = document.getElementById('myChart');
constctx = document.getElementById('myChart').getContext('2d');
constctx = $('#myChart');
constctx = 'myChart';

constctx2 = document.getElementById('myChart2');
constctx2 = document.getElementById('myChart2').getContext('2d');
constctx2 = $('#myChart2');
constctx2 = 'myChart2';

